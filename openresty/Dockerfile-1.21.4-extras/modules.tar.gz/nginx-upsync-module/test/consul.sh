#!/bin/sh

/usr/local/bin/consul agent -server -bootstrap -data-dir=/tmp/consul
